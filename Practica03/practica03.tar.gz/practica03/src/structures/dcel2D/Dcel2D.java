package geom.structures.dcel2D;

import java.util.TreeMap;
import java.util.List;
import java.util.Iterator;

import processing.core.PApplet;

/**
 * Implementación de la estructura de datos Double Connected Edge List
 * para representar una subdivision planar (dos dimensiones).
 * Se mantienen tres registros: Caras, Aritstas y Vertices.
 * Dado que una arista es adyacente a dos caras, una arista
 * se guarda en dos registros llamados half-edge.
 *
 * Ocupa la implementación en la JavaAPI de los árboles rojo-negro para
 * guardar los registros.
 *
 */
public class Dcel2D {

	// Registros comunes de la DCEL
	public TreeMap<String, Vertex2D> vertices;
	public TreeMap<String, HalfEdge2D> halfEdges;
	public TreeMap<String, Face2D> faces;

	/**
	 * Construye una DCEL vacía.
	 * Inicia los registros de caras, aristas y vertices vacios.
	 *
	 */
	public Dcel2D() {
		this.vertices = new TreeMap<String, Vertex2D>();
		this.halfEdges = new TreeMap<String, HalfEdge2D>();
		this.faces = new TreeMap<String, Face2D>();
	}

	/**
	 * Construye una DCEL con los registros dados.
	 *
	 * @param vertices Registro de vertices en un árbol rojo-negro.
	 * @param halfEdges Registro de vertices en un árbol rojo-negro.
	 * @param faces Registro de vertices en un árbol rojo-negro.
	 */
	public Dcel2D(TreeMap<String, Vertex2D> vertices, TreeMap<String, HalfEdge2D> halfEdges, TreeMap<String, Face2D> faces) {
		this.vertices = vertices;
		this.halfEdges = halfEdges;
		this.faces = faces;
	}

	/**
	 * Agrega una cara al registro de caras.
	 *
	 * @param face La cara a agregar.
	 */
	public void addFace(Face2D face) {
		if(!this.faces.containsKey(face.getId())) {
			this.faces.put(face.getId(), face);
		}
	}

	/**
	 * Agrega una arista al registro de aristas.
	 *
	 * @param halfEdge La arista por agregar.
	 */
	public void addHalfEdge(HalfEdge2D halfEdge) {
		if(!this.halfEdges.containsKey(halfEdge.getId())) {
			this.halfEdges.put(halfEdge.getId(), halfEdge);
		}
	}

	/**
	 * Agrega un vertice al registro de vertices.
	 *
	 * @param vertex El vertice por agregar.
	 */
	public void addVertex(Vertex2D vertex) {
		if(!this.vertices.containsKey(vertex.getId())) {
			this.vertices.put(vertex.getId(), vertex);
		}
	}

	/**
	 * Obtiene el registro de la cara externa (la unica que no
	 * tiene componente exterior).
	 *
	 * @return Face2D La cara externa.
	 */
	public Face2D getOuterFace() {
		Iterator<String> facesIterator = this.faces.keySet().iterator();
		while(facesIterator.hasNext()) {
			String faceId = facesIterator.next();
			Face2D face = this.faces.get(faceId);
			if(face.outerComponent == null) {
				return face;
			}
		}

		return null;
	}


	/**
	 * Dibuja la DCEL en un sketch.
	 *
	 * @param processing El sketch donde se debe pintar la DCEL.
	 */
	public void draw(PApplet processing) {
		// Tu código va aqui
	}

	/**
	 * Obtiene la lista de todas las aristas adyacentes aĺ vértice dado,
	 * esto es, todas las aristas que tengan como origen al vértice.
	 *
	 * @param vertex El vértice dado.
	 */
	public List<HalfEdge2D> adjacentHalfEdges(Vertex2D vertex) {
		// Tu código va aqui
		return null;
	}

	/**
	 * Obtiene la lista de todas las caras adyacentes a ĺa cara dada,
	 * esto es, todas las caras que comparten una arista con la cara.
	 *
	 * @param face La cara dada.
	 */
	public List<Face2D> adjacentFaces(Face2D face) {
		// Tu código va aqui
		return null;
	}

	/**
	 * Obtiene la lista de todas las aristas adyacentes a una cara,
	 * esto es, todas las aristas que tienen del lado izquierdo a la
	 * cara.
	 *
	 * NOTA: observa que además del componente externo, las aristas
	 * de los componentes internos también tienen del lado izquierdo
	 * a la cara.
	 *
	 * @param face La cara dada.
	 */
	public List<HalfEdge2D> adjacentHalfEdges(Face2D face) {
		// Tu código va aqui
		return null;
	}

	/**
	 * Imprime los registros en modo de tabla.
	 *
	 */
	public void printTables() {

		System.out.println("========================================");
		System.out.println("                 VERTICES");
		System.out.println("========================================");
		System.out.println("\tId\tCoordinates\t  Inc. Edge");
		System.out.println("----------------------------------------");

		Iterator<String> verticesIterator = this.vertices.keySet().iterator();
		while(verticesIterator.hasNext()) {

			String vertexId = verticesIterator.next();
			Vertex2D vertex = this.vertices.get(vertexId);

			System.out.print("\t" + vertexId);
			System.out.print("\t(" + vertex.x + ", " + vertex.y + ")");
			System.out.println("\t  " + vertex.incidentEdge.getId());
		}

		System.out.println("");
		System.out.println("===============================================================");
		System.out.println("                           HALF EDGES");
		System.out.println("===============================================================");
		System.out.println("\t Id\tOrigin\tEnd\tPrev\tNext\tTwin\tInc. Face");
		System.out.println("---------------------------------------------------------------");

		Iterator<String> halfEdgesIterator = this.halfEdges.keySet().iterator();
		while(halfEdgesIterator.hasNext()) {

			String halfEdgeId = halfEdgesIterator.next();
			HalfEdge2D halfEdge = this.halfEdges.get(halfEdgeId);

			System.out.print("\t" + halfEdgeId);
			System.out.print("\t " + halfEdge.origin.getId());
			System.out.print("\t" + halfEdge.end.getId());
			System.out.print("\t" + halfEdge.prev.getId());
			System.out.print("\t" + halfEdge.next.getId());
			System.out.print("\t" + halfEdge.twin.getId());
			System.out.println("\t  " + halfEdge.incidentFace.getId());
		}

		System.out.println("");
		System.out.println("========================================");
		System.out.println("                 FACES");
		System.out.println("========================================");
		System.out.println("\tId\tOuter Comp.\tInner Comps.");
		System.out.println("----------------------------------------");

		Iterator<String> facesIterator = this.faces.keySet().iterator();
		while(facesIterator.hasNext()) {

			String faceId = facesIterator.next();
			Face2D face = this.faces.get(faceId);

			System.out.print("\t" + faceId);
			if(face.outerComponent == null) {
				System.out.print("\t   null");
			} else {
				System.out.print("\t   " + face.outerComponent.getId());
			}

			if(face.innerComponents == null) {
				System.out.println("\t          null");
			} else {
				System.out.print("\t       [ ");
				for (int i = 0; i < face.innerComponents.size(); i++) {
					HalfEdge2D component = face.innerComponents.get(i);
					System.out.print(component.getId() + " ");
				}
				System.out.println(" ]");
			}
		}
	}	
}
