package geom.structures.dcel2D;

import geom.structures.vector.Vector2D;
import java.util.List;

/**
 * Representación de una cara de una DCEL de dos dimensiones.
 *
 */
public class Face2D {

	// Identificador único dentro de la DCEL
	private String id;

	// Apuntador a una media arista que compone la componente exterior
	public HalfEdge2D outerComponent;

	// Mantiene una lista de las medias aristas que componen las
	// compontes interiores
	public List<HalfEdge2D> innerComponents;

	/**
	 * Constuye una cara con su id, componente externo y sus componentes internos.
	 *
	 * @param id Identificador único dentro de la DCEL.
	 * @param outerComponent Arista del componente externo.
	 * @param innerComponents Lista de aristas de cada componente interno (a.k.a hoyo).
	 */
	public Face2D(String id, HalfEdge2D outerComponent, List<HalfEdge2D> innerComponents) {
		this.id = id;

		this.outerComponent = outerComponent;
		this.innerComponents = innerComponents;
	}

	/**
	 * Obtiene el identificador de la cara.
	 *
	 * @return String El identificador de la cara.
	 */
	public String getId() {
		return this.id;
	}

	/**
	 * Evalua si la cara es la cara externa.
	 *
	 * @return boolean Si es la cara externa o no.
	 */
	public boolean isOuterFace() {
		return this.outerComponent == null;
	}
}
