package geom.algorithms.triangulation.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertNull;

import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.junit.Test;

import processing.core.PApplet;
import geom.algorithms.triangulation.MonotoneDivision;
import geom.structures.dcel2D.*;

import java.util.Iterator;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class MonotoneDivisionTest {

	@Test
	public void test1MakeMonotone() {
		Dcel2D dcel = DCELUtils.readSvg("data/examplePolygon.svg", new PApplet());
		MonotoneDivision.makeMonotone(dcel);

		// Cada cara debe de ser monotona
		boolean allMonotone = true;
		Iterator<String> facesIterator = dcel.faces.keySet().iterator();
		while(facesIterator.hasNext()) {
			String faceId = facesIterator.next();
			Face2D face = dcel.faces.get(faceId);
			if(face.outerComponent != null) {
				allMonotone = allMonotone && isMonotone(face);
			}
		}
		assertTrue(allMonotone);
	}

	private boolean isMonotone(Face2D face) {

		// Obtenemos las medias aristas con origen extremo
		HalfEdge2D he = face.outerComponent;
		HalfEdge2D min = he;
		HalfEdge2D max = he;
		while(true) {

			// Comparamos para tener el maximo
			if(he.origin.y == max.origin.y) {
				max = he.origin.x < max.origin.x ? he : max;
			} else {
				max = he.origin.y > max.origin.y ? he : max;
			}

			// Comparamos para tener el mínimo
			if(he.origin.y == min.origin.y) {
				min = he.origin.x > min.origin.x ? he : min;
			} else {
				min = he.origin.y < min.origin.y ? he : min;
			}

			he = he.next;
			if(he.equals(face.outerComponent)) {
				break;
			}
		}

		// Recorremos de abajo hacia arriba
		he = min;
		boolean alwaysDown = true;
		while(!he.equals(max)) {
			alwaysDown = alwaysDown && (he.origin.y <= he.end.y);
			he = he.next;
		}

		// Recorremos de arriba hacia abajo
		he = max;
		boolean alwaysUp = true;
		while(!he.equals(min)) {
			alwaysUp = alwaysUp && (he.origin.y >= he.end.y);
			he = he.next;
		}

		return alwaysDown && alwaysUp;
	}
}