package geom.algorithms.convexHull.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertNotNull;

import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.junit.BeforeClass;
import org.junit.AfterClass;
import org.junit.Test;

import geom.util.VectorUtils;
import geom.algorithms.convexHull.IncrementalCH;
import geom.structures.Polygon2D;
import geom.structures.Vector2D;

import java.util.Random;
import java.util.List;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class IncrementalCHTest {

	private static IncrementalCH algorithm;
	private static Random rand;
	private static final float TWO_PI = (float) (Math.PI * 2.0);
	
	@BeforeClass
	public static void setupTestSuite() {
		algorithm = new IncrementalCH();
		rand = new Random();
	}

	@Test
	public void test1ConvexHull() {

		// Un punto
		Vector2D[] points = { new Vector2D(0.0f, 0.0f) };
		Polygon2D convexHull = algorithm.calculateConvexHull(points);
		assertNull(convexHull);

		// Puntos aleatorios
		points = generateRandomPoints(100);

		convexHull = algorithm.calculateConvexHull(points);
		assertNotNull(convexHull);

		assertTrue(convexHull.isConvex());
		for (int i = 0; i < points.length; i++) {
			assertTrue(convexHull.containsPoint(points[i]));
		}
	}

	@Test
	public void test2AppendPoint() {
		Vector2D[] convexPoints = new Vector2D[10];
		float angAmt = TWO_PI / 10.0f;
		int i = 0;
		for (float ang = 0.0f; ang <= TWO_PI && i < 10; ang += angAmt, i++) {
			float x = (float) Math.cos(ang) * 100.0f;
			float y = (float) Math.sin(ang) * 100.0f;

			convexPoints[i] = new Vector2D(x, y);
		}

		Polygon2D convexHull = algorithm.calculateConvexHull(convexPoints);
		assertNotNull(convexHull);

		int beforeSize = convexHull.size();
		convexHull = algorithm.append(convexHull, new Vector2D(0.0f, 0.0f));
		assertNotNull(convexHull);
		assertEquals(beforeSize, convexHull.size());

		convexHull = algorithm.append(convexHull, new Vector2D(500.0f, 500.0f));
		assertNotNull(convexHull);
		assertTrue(convexHull.isConvex());
		assertEquals(beforeSize + 1, convexHull.size());
	}

	@Test
	public void test3TangentPoints() {
		Vector2D[] points = generateRandomPoints(100);

		Polygon2D convexHull = algorithm.calculateConvexHull(points);
		assertNotNull(convexHull);
		assertTrue(convexHull.isConvex());

		Vector2D testVector = new Vector2D(500.0f, 500.0f);
		Vector2D[] tangentPoints = algorithm.getTangentsPoints(convexHull, testVector);
		assertNotNull(tangentPoints);
		assertEquals(2, tangentPoints.length);

		assertTrue(testOneSide(tangentPoints[0], testVector, points));
		assertTrue(testOneSide(tangentPoints[1], testVector, points));
	}

	@AfterClass
	public static void finishTestSuite() {
		algorithm = null;
		rand = null;
	}

	private boolean testOneSide(Vector2D a, Vector2D b, Vector2D[] points) {
		boolean oneSide = true;
		float lastArea = VectorUtils.area2(a, b, points[0]);
		for (int i = 1; i < points.length; i++) {
			float area2 = VectorUtils.area2(a, b, points[i]);
			oneSide = oneSide && ((lastArea * area2) >= 0.0f);

			lastArea = area2;
		}
		
		return oneSide;
	}

	// Genera puntos no colineales
	private Vector2D[] generateRandomPoints(int n) {
		Vector2D[] points = new Vector2D[n];

		float x, y;
		Vector2D newPoint;
		for (int i = 0; i < n; i++) {
			x = (float) Math.floor(rand.nextFloat() * 700.0f);
			y = (float) Math.floor(rand.nextFloat() * 700.0f);
			newPoint = new Vector2D(x, y);

			if(i < 3) {
				points[i] = newPoint;
			} else {
				while(true) {
					Vector2D vecA, vecB;
					float area2;

					boolean noCollineal = true;
					for (int j = 0; j < i; j++) {
						for (int k = 0; k < i; k++) {
							if(j != k) {
								vecA = points[j];
								vecB = points[k];

								area2 = VectorUtils.area2(vecA, vecB, newPoint);
								noCollineal = noCollineal && (area2 != 0.0f);
							}
						}
					}

					if(noCollineal) {
						break;
					} else {
						x = (float) Math.floor(rand.nextFloat() * 700.0f);
						y = (float) Math.floor(rand.nextFloat() * 700.0f);
						newPoint = new Vector2D(x, y);
					}
				}

				points[i] = newPoint;
			}
		}

		return points;
	}
}
