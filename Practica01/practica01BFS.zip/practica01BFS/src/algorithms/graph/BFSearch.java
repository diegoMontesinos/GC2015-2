package geom.algorithms.graph;

import geom.structures.graph.*;
import java.util.List;

/**
 * Implementación del algoritmo de Busqueda en anchura
 * (BFS - Breadth First Search), que recorre (y busca)
 * sistemáticamente una gráfica.
 *
 */
public class BFSearch {

	/**
	 * Constructor por default.
	 * Inicializa las variables de clase necesaras.
	 *
	 */
	public BFSearch() {
	}

	/**
	 * Encuentra el arbol producido por la búsqueda cuya
	 * raíz es el vértice x.
	 *
	 * @param Graph La gráfica de trabajo.
	 * @param x El vertice de inicio.
	 * @return Grap El arbol.
	 */
	public Graph getTree(Graph graph, GraphVertex x) {
		return null;
	}

	/**
	 * Encuentra un camino entre el vértice x y el vértice y.
	 * Devuelve nulo si tal camino no existe.
	 *
	 * @param Graph La gráfica de trabajo.
	 * @param x El vertice inicio.
	 * @param y El vertice final.
	 * @return Grap El arbol
	 */
	public Graph getPath(Graph graph, GraphVertex x, GraphVertex y) {
		return null;
	}

	/**
	 * Devuelve la lista de todos los vertices alcanzables desde
	 * x en el orden de la búsqueda.
	 *
	 * @param Graph La gráfica de trabajo.
	 * @param x El vertice inicio.
	 * @return List<GraphVertex> La lista de los vertices ordenados
	 */
	public List<GraphVertex> vertexInOrder(Graph graph, GraphVertex x) {
		return null;
	}

	/**
	 * Verifica si una grafica es conexa o no.
	 *
	 * @param Graph La gráfica de trabajo.
	 * @return boolean Si la grafica es conexa o no.
	 */
	public boolean isConnected(Graph graph) {
		return false;
	}

}