package geom.util;

import processing.core.PVector;
import geom.structures.Vector2D;

/**
 * Funciones de utileria para cálculo con vectores
 *
 */
public class VectorUtils {

	/**
	 * Calcula el area con signo basado en el producto cruz.
	 *
	 * Ayuda para el giro:
	 * 0 : colineal
	 * - : vuelta a la izquierda
	 * + : vuelta a la derecha
	 * 
	 * @param a Primer vector
	 * @param b Segundo vector
	 * @param c Tercer vector
	 * @return float Area con signo calculada
	 */
	public static float area2(Vector2D a, Vector2D b, Vector2D c) {
		float det = ((b.vector.x - a.vector.x) * (c.vector.y - b.vector.y)) - ((c.vector.x - b.vector.x) * (b.vector.y - a.vector.y));
		return det;
	}

}