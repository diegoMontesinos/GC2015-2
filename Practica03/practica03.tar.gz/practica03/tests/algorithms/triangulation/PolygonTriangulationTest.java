package geom.algorithms.triangulation.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertNull;

import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.junit.Test;

import processing.core.PApplet;
import geom.algorithms.triangulation.PolygonTriangulation;
import geom.structures.dcel2D.*;

import java.util.Iterator;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class PolygonTriangulationTest {

	@Test
	public void test1TriangulatePolygon() {
		Dcel2D dcel = DCELUtils.readSvg("data/examplePolygon.svg", new PApplet());
		PolygonTriangulation.triangulatePolygon(dcel);

		// Todos deben de ser triangulos
		boolean allTriangles = true;
		Iterator<String> facesIterator = dcel.faces.keySet().iterator();
		while(facesIterator.hasNext()) {
			String faceId = facesIterator.next();
			Face2D face = dcel.faces.get(faceId);
			if(face.outerComponent != null) {
				allTriangles = allTriangles && isTriangle(face);
			}
		}
		assertTrue(allTriangles);
	}

	private boolean isTriangle(Face2D face) {
		HalfEdge2D heA = face.outerComponent;
		HalfEdge2D heB = heA.next.next.next;
		return heA.equals(heB);
	}
}