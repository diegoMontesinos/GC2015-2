package geom.structures.vector;

/**
 * Representa un vector en el plano, contiene operaciones básicas
 * de vectores.
 *
 */
public class Vector2D {

	// Coordenadas
	public float x, y;

	/**
	 * Construye el vector en el origen.
	 *
	 */
	public Vector2D() {
		this.x = 0.0f;
		this.y = 0.0f;
	}

	/**
	 * Construye el vector dadas sus coordenadas
	 *
	 * @param x La coordenada x del vector.
	 * @param y La coordenada y del vector.
	 */
	public Vector2D(float x, float y) {
		this.x = x;
		this.y = y;
	}

	/**
	 * Compara dos vectores para ver si son iguales.
	 *
	 * @return boolean El test de si son iguales
	 */
	public boolean equals( Vector2D vec2D ) {
		return this.x == vec2D.x && this.y == vec2D.y; 
	}

}
