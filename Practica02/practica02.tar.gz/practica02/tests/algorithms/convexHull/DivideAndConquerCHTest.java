package geom.algorithms.convexHull.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertNotNull;

import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.junit.BeforeClass;
import org.junit.AfterClass;
import org.junit.Test;

import geom.util.VectorUtils;
import geom.algorithms.convexHull.DivideAndConquerCH;
import geom.structures.Polygon2D;
import geom.structures.Vector2D;

import java.util.Random;
import java.util.List;
import java.util.LinkedList;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class DivideAndConquerCHTest {

	private static DivideAndConquerCH algorithm;
	private static Random rand;
	private static final float TWO_PI = (float) (Math.PI * 2.0);

	private static LinkedList<Vector2D> pointsA, pointsB;

	@BeforeClass
	public static void setupTestSuite() {
		algorithm = new DivideAndConquerCH();
		rand = new Random();

		pointsA = new LinkedList<Vector2D>();
		pointsA.add(new Vector2D(273.0f, 658.0f));
		pointsA.add(new Vector2D(482.0f, 673.0f));
		pointsA.add(new Vector2D(429.0f, 519.0f));
		pointsA.add(new Vector2D(267.0f, 475.0f));
		pointsA.add(new Vector2D(164.0f, 556.0f));
		pointsA.add(new Vector2D(203.0f, 621.0f));

		pointsB = new LinkedList<Vector2D>();
		pointsB.add(new Vector2D(430.0f, 283.0f));
		pointsB.add(new Vector2D(557.0f, 353.0f));
		pointsB.add(new Vector2D(640.0f, 222.0f));
		pointsB.add(new Vector2D(611.0f, 142.0f));
		pointsB.add(new Vector2D(523.0f, 84.0f));
		pointsB.add(new Vector2D(434.0f, 68.0f));
		pointsB.add(new Vector2D(395.0f, 202.0f));
	}

	@Test
	public void test1ConvexHull() {

		// Un punto
		Vector2D[] points = { new Vector2D(0.0f, 0.0f) };
		Polygon2D convexHull = algorithm.calculateConvexHull(points);
		assertNull(convexHull);

		// Puntos aleatorios
		points = generateRandomPoints(100);

		convexHull = algorithm.calculateConvexHull(points);
		assertNotNull(convexHull);

		assertTrue(convexHull.isConvex());
		for (int i = 0; i < points.length; i++) {
			assertTrue(convexHull.containsPoint(points[i]));
		}
	}

	@Test
	public void test2Merge() {
		Polygon2D polA = new Polygon2D(pointsA);
		Polygon2D polB = new Polygon2D(pointsB);

		Polygon2D convexHull = algorithm.merge(polA, polB);
		assertNotNull(convexHull);
		assertTrue(convexHull.isConvex());

		List<Vector2D> vertexesA = polA.getVertexes();
		assertNull(vertexesA);
		for (int i = 0; i < vertexesA.size(); i++) {
			assertTrue(convexHull.containsPoint(vertexesA.get(i)));
		}

		List<Vector2D> vertexesB = polB.getVertexes();
		assertNull(vertexesB);
		for (int i = 0; i < vertexesB.size(); i++) {
			assertTrue(convexHull.containsPoint(vertexesB.get(i)));
		}
	}

	@Test
	public void test3Tangents() {
		Polygon2D polA = new Polygon2D(pointsA);
		Polygon2D polB = new Polygon2D(pointsB);

		Vector2D[] lowerTangent = algorithm.getLowerTangent(polA, polB);
		assertNotNull(lowerTangent);
		assertEquals(2, lowerTangent.length);
		assertTrue(testOneSide(lowerTangent, polA));
		assertTrue(testOneSide(lowerTangent, polB));

		Vector2D[] upperTangent = algorithm.getUpperTangent(polA, polB);
		assertNotNull(upperTangent);
		assertEquals(2, upperTangent.length);
		assertTrue(testOneSide(upperTangent, polA));
		assertTrue(testOneSide(upperTangent, polB));
	}

	@AfterClass
	public static void finishTestSuite() {
		algorithm = null;
		rand = null;
	}

	private boolean testOneSide(Vector2D[] tangent, Polygon2D polygon) {
		List<Vector2D> vertexes = polygon.getVertexes();

		boolean oneSide = true;
		float lastArea = VectorUtils.area2(tangent[0], tangent[1], vertexes.get(0));
		for (int i = 1; i < vertexes.size(); i++) {
			float area2 = VectorUtils.area2(tangent[0], tangent[1], vertexes.get(i));
			oneSide = oneSide && ((lastArea * area2) >= 0.0f);

			lastArea = area2;
		}
		
		return oneSide;
	}

	// Genera puntos no colineales
	private Vector2D[] generateRandomPoints(int n) {
		Vector2D[] points = new Vector2D[n];

		float x, y;
		Vector2D newPoint;
		for (int i = 0; i < n; i++) {
			x = (float) Math.floor(rand.nextFloat() * 700.0f);
			y = (float) Math.floor(rand.nextFloat() * 700.0f);
			newPoint = new Vector2D(x, y);

			if(i < 3) {
				points[i] = newPoint;
			} else {
				while(true) {
					Vector2D vecA, vecB;
					float area2;

					boolean noCollineal = true;
					for (int j = 0; j < i; j++) {
						for (int k = 0; k < i; k++) {
							if(j != k) {
								vecA = points[j];
								vecB = points[k];

								area2 = VectorUtils.area2(vecA, vecB, newPoint);
								noCollineal = noCollineal && (area2 != 0.0f);
							}
						}
					}

					if(noCollineal) {
						break;
					} else {
						x = (float) Math.floor(rand.nextFloat() * 700.0f);
						y = (float) Math.floor(rand.nextFloat() * 700.0f);
						newPoint = new Vector2D(x, y);
					}
				}

				points[i] = newPoint;
			}
		}

		return points;
	}

}
