package geom.structures.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertNull;

import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.junit.BeforeClass;
import org.junit.AfterClass;
import org.junit.Test;

import geom.structures.Polygon2D;
import geom.structures.Vector2D;

import java.util.List;
import java.util.LinkedList;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class Polygon2DTest {

	private static LinkedList<Vector2D> points;
	private static LinkedList<Vector2D> convexPoints;
	private static Polygon2D polygon;

	private static final float TWO_PI = (float) (Math.PI * 2.0);

	@BeforeClass
	public static void setupTestSuite() {
		points = new LinkedList<Vector2D>();
		points.add(new Vector2D(383.0f, 600.0f));
		points.add(new Vector2D(583.0f, 593.0f));
		points.add(new Vector2D(590.0f, 261.0f));
		points.add(new Vector2D(576.0f, 112.0f));
		points.add(new Vector2D(430.0f, 194.0f));
		points.add(new Vector2D(420.0f, 87.0f));
		points.add(new Vector2D(271.0f, 17.0f));
		points.add(new Vector2D(371.0f, 233.0f));
		points.add(new Vector2D(197.0f, 246.0f));
		points.add(new Vector2D(117.0f, 136.0f));
		points.add(new Vector2D(74.0f, 418.0f));
		points.add(new Vector2D(144.0f, 541.0f));
		points.add(new Vector2D(95.0f, 611.0f));
		points.add(new Vector2D(218.0f, 640.0f));
		points.add(new Vector2D(203.0f, 484.0f));
		points.add(new Vector2D(125.0f, 390.0f));
		points.add(new Vector2D(273.0f, 362.0f));
		points.add(new Vector2D(253.0f, 509.0f));
		points.add(new Vector2D(309.0f, 581.0f));

		convexPoints = new LinkedList<Vector2D>();
		float angAmt = TWO_PI / 10.0f;
		for (float ang = 0.0f; ang <= TWO_PI; ang += angAmt) {
			float x = (float) Math.cos(ang) * 100.0f;
			float y = (float) Math.sin(ang) * 100.0f;

			convexPoints.add(new Vector2D(x, y));
		}
	}

	@Test
	public void test1AddingPoints() {
		polygon = new Polygon2D();
		for (int i = 0; i < points.size(); i++) {
			polygon.add(points.get(i));
		}
		assertEquals(points.size(), polygon.size());

		List<Vector2D> vertexes = polygon.getVertexes();
		assertNotNull(vertexes);
		assertEquals(points.size(), vertexes.size());

		int beginIdx = vertexes.lastIndexOf(points.get(0));
		assertTrue(beginIdx != -1);

		boolean allIn = true;
		for (int i = 0; i < points.size(); i++) {
			Vector2D vPolygon = vertexes.get((beginIdx + i) % vertexes.size());
			Vector2D point = points.get(i);

			allIn = allIn && vPolygon.equals(point);
		}
		assertTrue(allIn);
	}

	@Test
	public void test2CreateWithList() {
		polygon = new Polygon2D(points);
		assertEquals(points.size(), polygon.size());

		List<Vector2D> vertexes = polygon.getVertexes();
		assertNotNull(vertexes);
		assertEquals(points.size(), vertexes.size());

		int beginIdx = vertexes.lastIndexOf(points.get(0));
		assertTrue(beginIdx != -1);

		boolean allIn = true;
		for (int i = 0; i < points.size(); i++) {
			Vector2D vPolygon = vertexes.get((beginIdx + i) % vertexes.size());
			Vector2D point = points.get(i);

			allIn = allIn && vPolygon.equals(point);
		}
		assertTrue(allIn);
	}

	@Test
	public void test3ClockwiseVertexes() {
		List<Vector2D> vertexes = polygon.getClockwiseVertexes();
		assertNotNull(vertexes);
		assertEquals(points.size(), vertexes.size());

		int beginIdx = vertexes.lastIndexOf(points.get(0));
		assertTrue(beginIdx != -1);

		Vector2D vPolygon = vertexes.get(beginIdx);
		Vector2D point = points.get(0);
		assertTrue(vPolygon.equals(point));

		boolean allIn = true;
		int n = vertexes.size();

		for (int i = (n - 1), j = 1; i > 0; i--, j++) {
			vPolygon = vertexes.get((beginIdx + j) % n);
			point = points.get(i);

			allIn = allIn && vPolygon.equals(point);
		}
		assertTrue(allIn);
	}

	@Test
	public void test4ConvexStuffs() {
		assertTrue(!polygon.isConvex());
		polygon = new Polygon2D(convexPoints);
		assertTrue(polygon.isConvex());

		Vector2D origin = new Vector2D();
		assertTrue(polygon.containsPoint(origin));
		assertTrue(!polygon.containsPoint(new Vector2D(500.0f, 500.0f)));

		Vector2D centroid = polygon.getCentroid();
		assertNotNull(centroid);
		assertTrue(centroid.equals(origin));
	}

	@AfterClass
	public static void finishTestSuite() {
		polygon = null;
	}
}
