package geom.structures.vector;

/**
 * Funciones de utileria para cálculo con vectores.
 *
 */
public class VectorUtils {

	/**
	 * Calcula el area con signo basado en el producto cruz.
	 *
	 * Ayuda para el giro:
	 * 0 : colineal
	 * - : vuelta a la izquierda
	 * + : vuelta a la derecha
	 * 
	 * @param a Primer vector
	 * @param b Segundo vector
	 * @param c Tercer vector
	 * @return float Area con signo calculada
	 */
	public static float area2(Vector2D a, Vector2D b, Vector2D c) {
		float det = ((b.x - a.x) * (c.y - b.y)) - ((c.x - b.x) * (b.y - a.y));
		return det;
	}

}