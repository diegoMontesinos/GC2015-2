package geom.algorithms.convexHull;

import geom.structures.Polygon2D;
import geom.structures.Vector2D;

/**
 * Implementación del algoritmo divide y venceras
 * para construir el cierre convexo de un 
 * conjunto de puntos.
 *
 */
public class DivideAndConquerCH {

	/**
	 * Crea una instancia de este algoritmo.
	 *
	 */
	public DivideAndConquerCH() {
	}

	/**
	 * Calcula la pareja de puntos, uno en el cierre convexo A y otro en el B
	 * que forman la tangente inferior. En esta tangente, los dos cierres tienen
	 * que quedar del lado izquiedo del segumento dirigido del primer vertice
	 * al segundo vertice.
	 * 
	 * NOTA: En la pareja de puntos que se regresa como un arreglo donde el primer punto
	 * debe estar en el cierre convexo A y el segundo en B.
	 *
	 * @param convexHullA El primer cierre convexo
	 * @param convexHullB El segundo cierre convexo
	 * @return Vector2D[] Un arreglo de los dos puntos que hacen la tangente inferior.
	 */
	public Vector2D[] getLowerTangent(Polygon2D convexHullA, Polygon2D convexHullB) {
		return null;
	}

	/**
	 * Calcula la pareja de puntos, uno en el cierre convexo A y otro en el B
	 * que forman la tangente superior. En esta tangente, los dos cierres tienen
	 * que quedar del lado derecho del segumento dirigido del primer vertice
	 * al segundo vertice.
	 * 
	 * NOTA: En la pareja de puntos que se regresa como un arreglo donde el primer punto
	 * debe estar en el cierre convexo A y el segundo en B.
	 *
	 * @param convexHullA El primer cierre convexo
	 * @param convexHullB El segundo cierre convexo
	 * @return Vector2D[] Un arreglo de los dos puntos que hacen la tangente superior.
	 */
	public Vector2D[] getUpperTangent(Polygon2D convexHullA, Polygon2D convexHullB) {
		return null;
	}

	/**
	 * Calcula el cierre convexo dado un arreglo de puntos.
	 *
	 * @param points El arreglo de puntos para obtener el cierre
	 * @return Polygon2D El cierre convexo calculado.
	 */
	public Polygon2D calculateConvexHull(Vector2D[] points) {
		return null;
	}

	/**
	 * Calcula el cierre convexo de la unión de dos cierres convexos,
	 * es decir, combina soluciones.
	 *
	 * @param convexHullA El primer cierre convexo
	 * @param convexHullB El segundo cierre convexo
	 * @return Polygon2D El cierre convexo calculado.
	 */
	public Polygon2D merge(Polygon2D convexHullA, Polygon2D convexHullB) {
		return null;
	}

}
