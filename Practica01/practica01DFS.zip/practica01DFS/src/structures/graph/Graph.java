package geom.structures.graph;

import java.util.List;

/**
 * Implementación del concepto matemático de gráfica o grafo.
 * Un grafo consiste en un conjunto finito de vertices y un conjunto de pares
 * de vertices (x, y) llamados aristas.
 *
 */
public class Graph {

	/**
	 * Constructor por default.
	 * Inicializa las variables de clase necesaras.
	 *
	 */
	public Graph() {
	}

	/**
	 * Agrega un vertice a la gráfica.
	 *
	 * @param x El vertice a agregar
	 */
	public void addVertex(GraphVertex x) {
	}

	/**
	 * Obtiene un vertice dado su identificador.
	 *
	 * @param id El identificador del vertice
	 * @return GraphVertex El vertice o nulo si no existe el vertice con ese identificador
	 */
	public GraphVertex getVertexById(String id) {
		return null;
	}

	/**
	 * Elimina un vertice dado su identificador.
	 *
	 * @param id El identificador del vertice
	 */
	public void deleteVertex(String id) {
	}

	/**
	 * Agrega la arista con los vertices (x, y).
	 * Note que al ser una grafica no dirigida entonces
	 * tambien se agregara la arista (y, x).
	 *
	 * @param x Primer vertice extremo
	 * @param y Segundo vertice extremo
	 */
	public void addEdge(GraphVertex x, GraphVertex y) {
	}

	/**
	 * Elimina una arista dado los identificadores
	 * de sus extremos.
	 *
	 * @param idX El identificador del primer vertice extremo
	 * @param idY El identificador del segundo vertice extremo
	 */
	public void deleteEdge(String idX, String idY) {
	}

	/**
	 * Verifica si x es adyacente a y dados los identificadores,
	 * es decir, si existe la arista (x, y) en la gráfica.
	 * Note que al ser una grafica no dirigida entonces si la arista
	 * (x, y) existe, entonces la arista (y, x) también.
	 *
	 * @param idX El identificador del primer vertice extremo
	 * @param idY El identificador del segundo vertice extremo
	 * @return boolean Si los vertices son adyacentes
	 */
	public boolean isAdjacent(String idX, String idY) {
		return false;
	}

	/**
	 * Devuelve a los vecinos del vertice x, es decir,
	 * todos los vértices adyacentes a x.
	 * Esta lista esta ordenada de forma radial.
	 * Si x no tiene aristas entonces regresa la lista vacia.
	 *
	 * @param x El vertice
	 * @return List<GraphVertex> Los vecinos del vertice
	 */
	public List<GraphVertex> neighbors(GraphVertex x) {
		return null;
	}

	/**
	 * Devuelve el numero de vertices en la grafica.
	 *
	 * @return int El numero de vertices
	 */
	public int getSize() {
		return -1;
	}

	/**
	 * Limpia la gráfica y la pone vacia.
	 *
	 */
	public void clear() {
	}

}