package geom.structures.dcel2D;

import geom.structures.vector.Vector2D;

/**
 * Representación de un vertice de una DCEL de dos dimensiones.
 * Hereda de la clase Vector2D, ya que también es un punto en el
 * plano y facilita las operaciones de la DCEL.
 *
 */
public class Vertex2D extends Vector2D {

	// Identificador único dentro de la DCEL
	private String id;

	// Arista incidente (de la cual es origen)
	public HalfEdge2D incidentEdge;

	/**
	 * Constuye un vértice con su id y sus coordenadas x, y.
	 *
	 * NOTA: El vértice se crea separado, es decir, sin arista incidente.
	 *
	 * @param id Identificador único dentro de la DCEL.
	 * @param x La coordenada x del vertice.
	 * @param y La coordenada y del vertice.
	 */
	public Vertex2D(String id, float x, float y) {
		super(x, y);

		this.id = id;
		this.incidentEdge = null;
	}

	/**
	 * Obtiene el identificador de la arista.
	 *
	 * @return String El identificador de la arista.
	 */
	public String getId () {
		return this.id;
	}

	/**
	 * Compara dos vertices para ver si son iguales.
	 *
	 * @return boolean El test de si son iguales
	 */
	public boolean equals(Vertex2D v) {
		return this.x == v.x && this.y == v.y;
	}
}
