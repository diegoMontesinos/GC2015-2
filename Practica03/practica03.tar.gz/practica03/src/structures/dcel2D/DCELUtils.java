package geom.structures.dcel2D;

import geom.structures.dcel2D.*;
import geom.structures.vector.VectorUtils;
import geom.structures.vector.Vector2D;

import java.util.TreeMap;
import java.util.LinkedList;
import java.util.Iterator;

import processing.data.XML;
import processing.core.PApplet;

/**
 * Clase con algunos métodos de utilería para manejo y 
 * construcción de la estructura Double Connected Edge List (DCEL).
 *
 */
public class DCELUtils {

	/**
	 * Construye una DCEL a partir de la información contenida
	 * en un archivo svg que representa a dicha DCEL.
	 *
	 * @param svgFilePath La ruta hacia el archivo svg.
	 * @param processing Una referencia hacia un PApplet para poder usar
	 * métodos de Processing.
	 * @return Dcel2D La DCEL contruida.
	 */
	public static Dcel2D readSvg(String svgFilePath, PApplet processing) {

		// Cargamos el svg
		XML svg = processing.loadXML(svgFilePath);
		XML[] svgPolygons = svg.getChildren("polygon");

		// Creamos un redblack tree para mantener los tres registros
		TreeMap<String, Vertex2D> vertices = new TreeMap<String, Vertex2D>();
		TreeMap<String, HalfEdge2D> halfEdges = new TreeMap<String, HalfEdge2D>();
		TreeMap<String, Face2D> faces = new TreeMap<String, Face2D>();

		// Iteramos los elementos polygon del svg
		for (int i = 0; i < svgPolygons.length; i++) {

			// Obtenemos el svg del poligono
			XML svgPolygon = svgPolygons[i];

			// Obtenemos los datos parseando el atributo points del elemento polygon
			String verticesStr = svgPolygon.getString("points");
			String[] verticesData = verticesStr.split(" ");

			// Creamos las medias aristas de la cara que sera el poligono
			HalfEdge2D[] component = new HalfEdge2D[verticesData.length];

			// Iteramos en cada dato de vertice
			for (int j = 0; j < verticesData.length; j++) {

				// Obtenemos los ids de origen y destino
				// NOTA: cada id es la cadena 'x,y'
				String idOrigin = verticesData[j];
				String idEnd = verticesData[(j + 1) % verticesData.length];

				// Obtenemos los vertices y/o los creamos
				Vertex2D origin = null, end = null;
				if(!vertices.containsKey(idOrigin)) {

					// Creamos el vertice
					String[] coords = idOrigin.split(",");
					origin = new Vertex2D(idOrigin, Float.parseFloat(coords[0]), Float.parseFloat(coords[1]));

					// Lo guardamos
					vertices.put(idOrigin, origin);
				} else {
					origin = vertices.get(idOrigin);
				}

				if(!vertices.containsKey(idEnd)) {

					// Creamos el vertice
					String[] coords = idEnd.split(",");
					end = new Vertex2D(idEnd, Float.parseFloat(coords[0]), Float.parseFloat(coords[1]));

					// Lo guardamos
					vertices.put(idEnd, end);
				} else {
					end = vertices.get(idEnd);
				}

				// Creamos la media arista con el id 'idOrigin-idEnd'
				HalfEdge2D halfEdge = new HalfEdge2D(idOrigin + "-" + idEnd, origin, end);

				// La agregamos al componente
				component[j] = halfEdge;
			}

			// Hacemos comprobacion de que venga en counterclockwise
			if(!validOrder(component)) {
				component = fixOrder(component);
			}

			// Construye la cara y la guarda
			Face2D face = DCELUtils.buildFace(verticesStr, component);

			// Guardamos las medias aristas creadas
			for (int j = 0; j < component.length; j++) {
				HalfEdge2D he = component[j];

				// Si no la hemos creado
				if(!halfEdges.containsKey(he.getId())) {
					halfEdges.put(he.getId(), he);
				}
				else {
					Face2D otherFace = halfEdges.get(he.getId()).incidentFace;
					System.out.println(face.getId() + " y " + otherFace.getId() + " tienen una arista encimada!");
					return null;
				}
			}

			faces.put(verticesStr, face);
		}

		// Ahora pegamos las caras (asignamos gemelos) y obtenemos el componente de la cara exterior
		Iterator<String> iteHalfEdges = halfEdges.keySet().iterator();
		LinkedList<HalfEdge2D> feHalfEdges = new LinkedList<HalfEdge2D>();
		while(iteHalfEdges.hasNext()) {

			// Obtenemos la media arista con su id
			String heId = iteHalfEdges.next();
			HalfEdge2D he = halfEdges.get(heId);

			// Si no tiene gemelo aun
			if(he.twin == null) {

				// Obtenemos el id de su presunto gemelo
				String[] idParsed = heId.split("-");
				String twinId = idParsed[1] + "-" + idParsed[0];

				// Obtenemos al gemelo 
				HalfEdge2D twin = halfEdges.get(twinId);

				// Si no es nulo asignamos la relacion
				if(twin != null) {
					he.twin = twin;
					twin.twin = he;
				}
				// Si lo es, entonces he es gemelo de la cara exterior
				else {
					HalfEdge2D newHe = new HalfEdge2D(twinId, he.end, he.origin);
					newHe.twin = he;
					he.twin = newHe;

					// Agregamos al componente de la cara exterior
					feHalfEdges.add(newHe);
				}
			}
		}

		// Creamos el componente de la cara exterior
		HalfEdge2D[] feComponent = buildFeComponent(feHalfEdges);

		// Creamos el componente interno de la cara externa
		LinkedList<HalfEdge2D> feInnerComponent = new LinkedList<HalfEdge2D>();
		feInnerComponent.add(feComponent[0]);

		// Creamos la cara exterior y la agregamos a las caras
		Face2D fe = new Face2D("fe", null, feInnerComponent);
		faces.put("fe", fe);

		// Ponemos las medias aristas restantes y le asignamos la cara
		for (int i = 0; i < feComponent.length; i++) {
			halfEdges.put(feComponent[i].getId(), feComponent[i]);
			feComponent[i].incidentFace = fe;
		}

		// Regresamos la cara con los registros creados
		return new Dcel2D(vertices, halfEdges, faces);
	}

	/**
	 * Revisa que el orden de un componente sea válido, es decir, que venga en
	 * counterclockwise.
	 */
	private static boolean validOrder(HalfEdge2D[] component) {
		float sum = 0.0f;
		for (int i = 0; i < component.length; i++) {
			HalfEdge2D he = component[i];
			float mult = (he.end.x - he.origin.x) * (he.end.y + he.origin.y);
			sum += mult;
		}

		return sum >= 0.0;
	}

	/**
	 * Arregla el orden de un componente.
	 */
	private static HalfEdge2D[] fixOrder(HalfEdge2D[] component) {
		HalfEdge2D[] fixed = new HalfEdge2D[component.length];
		for (int i = 0; i < component.length; i++) {
			Vertex2D origin = component[i].origin;
			Vertex2D end = component[i].end;

			HalfEdge2D halfEdge = new HalfEdge2D(end.getId() + "-" + origin.getId(), end, origin);
			fixed[component.length - (i + 1)] = halfEdge;
		}

		return fixed;
	}

	/**
	 * Construye el componente de la cara externa.
	 */
	private static HalfEdge2D[] buildFeComponent(LinkedList<HalfEdge2D> feHalfEdges) {

		// Creamos el componente con la primera media arista
		HalfEdge2D[] feComponent = new HalfEdge2D[feHalfEdges.size()];
		feComponent[0] = feHalfEdges.removeFirst();

		// Vamos llenando el componente ordenadamente
		for (int i = 1; i < feComponent.length; i++) {

			// Obtenemos el ultimo metido
			HalfEdge2D heA = feComponent[i - 1];

			// Buscamos la siguiente media arista
			for (int j = 0; j < feHalfEdges.size(); j++) {
				HalfEdge2D heB = feHalfEdges.get(j);

				// Si el final es el origen de la otra
				if(heA.end.getId() == heB.origin.getId()) {

					// La metemos
					feComponent[i] = heB;

					// Las relacionamos
					heA.next = heB;
					heB.prev = heA;

					// Removemos de la lista
					feHalfEdges.remove(j);
					break;
				}
			}
		}

		// Relacionamos el final con el principio
		feComponent[0].prev = feComponent[feComponent.length - 1];
		feComponent[feComponent.length - 1].next = feComponent[0];

		return feComponent;
	}

	/**
	 * Construye una arista completa, es decir, sus dos medias aristas
	 */
	public static HalfEdge2D[] buildCompleteEdge(String prefixId, Vertex2D origin, Vertex2D end) {

		// Creamos las dos medias aristas con origen y final correspondientes
		HalfEdge2D he1 = new HalfEdge2D(prefixId + ".1", origin, end);
		HalfEdge2D he2 = new HalfEdge2D(prefixId + ".2", end, origin);

		// Relacion de gemelos
		he1.twin = he2;
		he2.twin = he1;

		// Creamos las dos medias aristas
		HalfEdge2D[] doubleEdge = { he1, he2 };
		return doubleEdge;
	}

	/**
	 * Construye una cara dado su id y su componente
	 */
	public static Face2D buildFace(String id, HalfEdge2D[] halfEdges) {

		// Creamos la cara (ponemos como refencia de componente a la primera media arista)
		Face2D face = new Face2D(id, halfEdges[0], null);

		// Componemos prev y next
		linkComponent(halfEdges);

		// Recorremos las medias aristas
		for (int i = 0; i < halfEdges.length; i++) {

			// Asignamos la cara incidente
			halfEdges[i].incidentFace = face;
		}

		return face;
	}

	/**
	 * Enlaza un componente, es decir, asigna el previo y el siguiente.
	 */
	public static void linkComponent(HalfEdge2D[] component) {

		// Iteramos el componente
		for (int i = 0; i < component.length; i++) {
			HalfEdge2D he = component[i];
			HalfEdge2D nextHe = component[(i + 1) % component.length];

			// Asignamos previo y siguiente
			he.next = nextHe;
			nextHe.prev = he;
		}
	}
}