package geom.algorithms.triangulation;

import geom.structures.dcel2D.*;

/**
 * Implementación del algoritmo para dividir polígono en
 * piezas monótonas con respecto al ejeY.
 * Ocupa el Algoritmo de Barrido de Línea descrito en el
 * capítulo 3 de "Computational Geometry: Algorithms and applications".
 *
 * HINT: podrías ocupar otros métodos extra cuya firma podría ser algo como:
 *  handleStartVertex(vi, status, dcel)
 *  handleMergeVertex(vi, status, dcel)
 *  handleRegularVertex(vi, status, dcel)
 *  handleSplitVertex(vi, status, dcel)
 *  handleEndVertex(vi, status, dcel)
 *  connectDiagonal(origin, end, status, dcel)
 *
 * HINT: Comienza por definir las estructuras de eventos y status del algoritmo.
 */
public class MonotoneDivision {

	/**
	 * Divide un polígono simple en piezas monótonas con respecto al eje Y.
	 * Este polígono está descrito en la DCEL de entrada.
	 *
	 * Esta división modifica la DCEL de entrada, por lo que todas
	 * las modificaciones se hacen sobre la estructura.
	 *
	 * @param dcel El polígono simple descrito en la DCEL
	 */
	public static void makeMonotone(Dcel2D dcel) {
	}
}