package geom.structures.dcel2D;

/**
 * Representación de una arista de una DCEL de dos dimensiones.
 *
 */
public class HalfEdge2D {

	// Identificador único dentro de la DCEL
	private String id;

	// Vertice de inicio
	public Vertex2D origin;

	// Vertice de final
	public Vertex2D end;

	// Arista gemela
	public HalfEdge2D twin;

	// Arista siguiente
	public HalfEdge2D next;

	// Arista previa
	public HalfEdge2D prev;

	// Cara incidente
	public Face2D incidentFace;

	/**
	 * Constuye una arista con su id, origen y final.
	 * Este constructor asigna automaticamente que la arista
	 * incidente al origen es la creada.
	 *
	 * NOTA: La arista se crea separada, es decir, sin gemela, ni previo, ni siguiente.
	 *
	 * @param id Identificador único dentro de la DCEL.
	 * @param origin Vertice de origen.
	 * @param end Vertice de final.
	 */
	public HalfEdge2D(String id, Vertex2D origin, Vertex2D end) {
		this.id = id;

		this.origin = origin;
		this.end = end;
		this.origin.incidentEdge = this;

		this.twin = null;
		this.next = null;
		this.prev = null;
		this.incidentFace = null;
	}

	/**
	 * Obtiene el identificador de la arista.
	 *
	 * @return String El identificador de la arista.
	 */
	public String getId () {
		return this.id;
	}

	/**
	 * Compara dos aristas para ver si son iguales.
	 *
	 * @return boolean El test de si son iguales
	 */
	public boolean equals(HalfEdge2D he) {
		return this.origin.equals(he.origin) && this.end.equals(he.end);
	}
}
