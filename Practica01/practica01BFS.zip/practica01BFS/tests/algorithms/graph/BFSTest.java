package geom.algorithms.graph.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertNotNull;

import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.junit.BeforeClass;
import org.junit.AfterClass;
import org.junit.Test;

import processing.core.PVector;
import geom.structures.graph.*;
import geom.algorithms.graph.BFSearch;
import java.util.Random;
import java.util.List;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class BFSTest extends GraphTestGenerator {

	private static Graph graph;
	private static Random rand;
	private static BFSearch bfs;
	
	@BeforeClass
	public static void setupTestSuite() {
		graph = new Graph();
		rand = new Random();
		bfs = new BFSearch();
	}

	@Test
	public void test1GetTree() {

		Graph testTree;

		// Graficas completas
		for (int n = 5; n < 10; n++) {
			if((n % 2) != 0) {
				graph = generateComplete(n);
				
				int idxRand = rand.nextInt(n);
				String idRand = "" + ABC.charAt(idxRand);

				testTree = bfs.getTree(graph, graph.getVertexById(idRand));
				assertNotNull(testTree);
				assertEquals(n, testTree.getSize());

				boolean connected = false;
				for (int i = 0; i < n; i++) {
					String neighborId = "" + ABC.charAt(i);
					if(i != idxRand) {
						connected = connected && graph.isAdjacent(idRand, neighborId);
					}
				}
				assertEquals(true, connected);
			}
		}

		graph = generateComplete(5);
		graph.addVertex(new GraphVertex("z", new PVector(rand.nextFloat() * 500.0f, rand.nextFloat() * 500.0f)));

		testTree = bfs.getTree(graph, graph.getVertexById("a"));
		assertNotNull(testTree);
		assertEquals(5, testTree.getSize());

		testTree = bfs.getTree(graph, graph.getVertexById("z"));
		assertNotNull(testTree);
		assertEquals(1, testTree.getSize());
	}

	@Test
	public void test2GetPath() {

		// Path con 5 vertices
		graph = generatePath(5);

		Graph path = bfs.getPath(graph, graph.getVertexById("a"), graph.getVertexById("e"));
		assertNotNull(path);
		assertEquals(5, path.getSize());

		boolean connected = true;
		for (int i = 1; i < 5; i++) {
			String idX = "" + ABC.charAt(i - 1);
			String idY = "" + ABC.charAt(i);

			connected = connected && path.isAdjacent(idX, idY);
		}
		assertEquals(true, connected);

		// Lo desconectamos y ya no hay path
		graph.deleteVertex("b");
		path = bfs.getPath(graph, graph.getVertexById("a"), graph.getVertexById("e"));
		assertNull(path);
	}

	@Test
	public void test3VertexInOrder() {
		graph = generateTestTree();

		List<GraphVertex> inOrder = bfs.vertexInOrder(graph, graph.getVertexById("a"));
		assertNotNull(inOrder);

		String orderedIds = "";
		for (int i = 0; i < inOrder.size(); i++) {
			orderedIds += inOrder.get(i).getId();
		}
		assertEquals("abcdefg", orderedIds);
	}

	@Test
	public void test3IsConnected() {
		graph.clear();
		assertEquals(true, bfs.isConnected(graph));

		graph = generateComplete(5);
		assertEquals(true, bfs.isConnected(graph));

		graph.addVertex(new GraphVertex("z", new PVector(rand.nextFloat() * 500.0f, rand.nextFloat() * 500.0f)));
		assertEquals(false, bfs.isConnected(graph));
	}

	@AfterClass
	public static void finishTestSuite() {
		graph = null;
		bfs = null;
		rand = null;
	}

}
