package geom.visualization;

import processing.core.PApplet;
import geom.structures.dcel2D.*;

public class DCELSketch extends PApplet {

	private Dcel2D dcel;

	public void setup() {
		size(700, 700);
		smooth();
		dcel = DCELUtils.readSvg("data/examplePolygon.svg", new PApplet());
	}

	public void draw() {
		background(255);
		dcel.draw(this);
		noLoop();
	}
}