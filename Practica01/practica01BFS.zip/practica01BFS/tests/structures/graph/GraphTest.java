package geom.structures.graph.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertNotNull;

import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.junit.BeforeClass;
import org.junit.AfterClass;
import org.junit.Test;

import processing.core.PVector;
import geom.structures.graph.*;
import java.util.Random;
import java.util.List;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class GraphTest {

	private static final String ABC = "abcdefghijklmnopqrstuvwxyz";
	private static final float HALF_PI = (float) (Math.PI * 0.5);
	private static final float TWO_PI = (float) (Math.PI * 2.0);
	private static Graph graph;
	private static Random rand;

	@BeforeClass
	public static void setupTestSuite() {
		graph = new Graph();
		rand = new Random();
	}

	@Test
	public void  test1AddAndGetVertex() {
		String testId = "" + ABC.charAt(rand.nextInt(ABC.length()));
		PVector testPos = new PVector(rand.nextFloat() * 500.0f, rand.nextFloat() * 500.0f);

		for (int i = 0; i < ABC.length(); i++) {
			String id = "" + ABC.charAt(i);
			GraphVertex vertex;
			if(id.equals(testId)) {
				vertex = new GraphVertex(id, testPos);
			} else {
				vertex = new GraphVertex(id, new PVector(rand.nextFloat() * 500.0f, rand.nextFloat() * 500.0f));
			}

			graph.addVertex(vertex);
		}

		// Test por un vertice inexistente
		assertNull(graph.getVertexById("1234"));

		// Test por un vertice que elegimos
		GraphVertex resVertex = graph.getVertexById(testId);
		assertNotNull(resVertex);

		if(resVertex != null) {

			// Test que sea el vertice elegido
			PVector resPosition = resVertex.getPosition();
			assertEquals(true, resVertex.getId().equals(testId) && resPosition.x == testPos.x && resPosition.y == testPos.y);
		}
	}

	@Test
	public void test2addAndProveEdges() {

		// No hay arista a b
		assertEquals(false, graph.isAdjacent("a", "b"));
		assertEquals(false, graph.isAdjacent("b", "a"));

		GraphVertex vertA = graph.getVertexById("a");
		assertNotNull(vertA);
		assertEquals(true, graph.isAdjacent("a", "a"));

		// Agrega algunos vertices aleatorios
		String friends = "";
		for (int i = 0; i < 5; i++) {
			String friendId = "" + ABC.charAt(rand.nextInt(ABC.length() - 2) + 1);

			GraphVertex vertFriend = graph.getVertexById(friendId);
			assertNotNull(vertFriend);

			friends += friendId;

			if(rand.nextDouble() < 0.5) {
				graph.addEdge(vertA, vertFriend);
			} else {
				graph.addEdge(vertFriend, vertA);
			}
		}

		// Test de que todos esten
		boolean allAdjacent = true;
		for (int i = 0; i < friends.length(); i++) {
			String friendId = "" + friends.charAt(i);

			allAdjacent = allAdjacent && graph.isAdjacent("a", friendId);
			allAdjacent = allAdjacent && graph.isAdjacent(friendId, "a");
		}
		assertEquals(true, allAdjacent);

		// Test agregando arista z y el primer amigo
		String friendId = "" + ABC.charAt(0);
		
		GraphVertex vertZ = graph.getVertexById("z");
		GraphVertex vertFriend = graph.getVertexById(friendId);
		assertNotNull(vertZ);
		assertNotNull(vertFriend);

		graph.addEdge(vertZ, vertFriend);
		assertEquals(true, graph.isAdjacent("z", friendId));
		assertEquals(true, graph.isAdjacent(friendId, "z"));
	}

	@Test
	public void test3GetSize() {
		assertEquals(ABC.length(), graph.getSize());
		graph.clear();
		assertEquals(0, graph.getSize());
	}

	@Test
	public void test4NeighborsInOrder() {

		// Metemos el centro
		GraphVertex vertA = new GraphVertex("a", new PVector(250.0f, 250.0f));
		graph.addVertex(vertA);

		// Generamos una vecindad ordenada
		GraphVertex[] neighbors = new GraphVertex[7];
		float ang = rand.nextFloat() * HALF_PI;
		for (int i = 0; i < neighbors.length; i++) {

			// Generamos la posicion
			float rad = (rand.nextFloat() * 150.0f) + 50.0f;
			PVector pos = new PVector((float) Math.cos(HALF_PI - ang), (float) Math.sin(HALF_PI - ang));
			pos.mult(rad);
			pos.x += vertA.getPosition().x;
			pos.y += vertA.getPosition().y;

			// Aumentamos el angulo
			float rest = (float) Math.abs(((TWO_PI - ang) * 0.5f) - 0.01f);
			ang += (rand.nextFloat() * rest) + 0.01f;

			// Creamos el vertice
			neighbors[i] = new GraphVertex("" + ABC.charAt(i + 1), pos);
		}

		// Hacemos un shuffle de los vertices
		for (int i = 0; i < (neighbors.length * 2); i++) {
			int indexA = rand.nextInt(neighbors.length);
			int indexB = rand.nextInt(neighbors.length);

			// Swap
			GraphVertex temp = neighbors[indexA];
			neighbors[indexA] = neighbors[indexB];
			neighbors[indexB] = temp;
		}

		// Agregamos los vertices y las aristas
		for (int i = 0; i < neighbors.length; i++) {
			graph.addVertex(neighbors[i]);
			graph.addEdge(vertA, neighbors[i]);
		}

		// Preguntamos por los vecinos de a
		List<GraphVertex> calcNeighbors = graph.neighbors(vertA);
		assertNotNull(calcNeighbors);

		// Que nos den todos los que metimos
		assertEquals(neighbors.length, calcNeighbors.size());

		// Que esten ordenados
		boolean ordered = true;
		for (int i = 0; i < calcNeighbors.size(); i++) {
			String id = "" + ABC.charAt(i + 1);
			String neighborId = calcNeighbors.get(i).getId();

			ordered = ordered && neighborId.equals(id);
		}

		// Que si esten todos donde deben de estar
		assertEquals(true, ordered);
	}

	@Test
	public void test5DeleteVertexEdge() {
		graph.clear();

		// Metemos dos vertice
		GraphVertex vertA = new GraphVertex("a", new PVector(rand.nextFloat() * 500.0f, rand.nextFloat() * 500.0f));
		GraphVertex vertB = new GraphVertex("b", new PVector(rand.nextFloat() * 500.0f, rand.nextFloat() * 500.0f));
		GraphVertex vertC = new GraphVertex("c", new PVector(rand.nextFloat() * 500.0f, rand.nextFloat() * 500.0f));

		graph.addVertex(vertA);
		graph.addVertex(vertB);
		graph.addVertex(vertC);

		graph.addEdge(vertA, vertB);
		graph.addEdge(vertB, vertC);

		// Prueba el borrado de aristas
		assertEquals(true, graph.isAdjacent("b", "c"));
		graph.deleteEdge("b", "c");
		assertEquals(false, graph.isAdjacent("b", "c"));

		// Prueba el borrado de vertice
		graph.deleteVertex("a");
		assertNull(graph.getVertexById("a"));
		assertEquals(false, graph.isAdjacent("a", "b"));

		// Prueba que solo queden dos vertices
		assertEquals(2, graph.getSize());
	}

	@AfterClass
	public static void finishTestSuite() {
		graph = null;
		rand = null;
	}

}