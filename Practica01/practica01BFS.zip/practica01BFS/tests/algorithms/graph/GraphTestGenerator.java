package geom.algorithms.graph.test;

import geom.structures.graph.*;
import processing.core.PVector;

public class GraphTestGenerator {

	protected static final float HALF_PI = (float) (Math.PI * 0.5);
	protected static final float TWO_PI = (float) (Math.PI * 2.0);
	protected static final String ABC = "abcdefghijklmnopqrstuvwxyz";

	protected static Graph generateComplete(int n) {
		Graph graph = new Graph();

		// Vertexes
		float ang = 0.0f;
		float angAmt = TWO_PI / n;
		for (int i = 0; i < n; i++) {
			PVector pos = new PVector();
			pos.x = (float) (Math.cos(ang) * 200.0 + 250.0);
			pos.y = (float) (Math.cos(ang) * 200.0 + 250.0);

			graph.addVertex(new GraphVertex("" + ABC.charAt(i), pos));

			ang -= angAmt;
		}

		// Edges
		for (int i = 0; i < n; i++) {
			String idX = "" + ABC.charAt(i);

			for(int j = (i + 1); j < n; j++) {
				String idY = "" + ABC.charAt(j);

				graph.addEdge(graph.getVertexById(idX), graph.getVertexById(idY));
			}
		}

		return graph;
	}

	protected Graph generatePath(int n) {
		Graph graph = new Graph();

		float x = 250.0f;
		GraphVertex lastVertex = null;
		for (int i = 0; i < n; i++) {

			GraphVertex vertex = new GraphVertex("" + ABC.charAt(i), new PVector(x, 250.0f));
			graph.addVertex(vertex);
			x += 250.0f;

			if(lastVertex != null) {
				graph.addEdge(lastVertex, vertex);
			}

			lastVertex = vertex;
		}

		return graph;
	}

	protected Graph generateTestTree() {
		GraphVertex[] vertexSet = {
			new GraphVertex("a", new PVector(80.0f, 253.0f)),
			new GraphVertex("b", new PVector(159.0f, 375.0f)),
			new GraphVertex("c", new PVector(154.0f, 159.0f)),
			new GraphVertex("d", new PVector(244.0f, 443.0f)),
			new GraphVertex("e", new PVector(241.0f, 292.0f)),
			new GraphVertex("f", new PVector(233.0f, 230.0f)),
			new GraphVertex("g", new PVector(233.0f, 75.0f))
		};

		Graph graph = new Graph();
		for (int i = 0; i < vertexSet.length; i++) {
			graph.addVertex(vertexSet[i]);
		}

		graph.addEdge(vertexSet[0], vertexSet[1]);
		graph.addEdge(vertexSet[0], vertexSet[2]);
		graph.addEdge(vertexSet[1], vertexSet[3]);
		graph.addEdge(vertexSet[1], vertexSet[4]);
		graph.addEdge(vertexSet[2], vertexSet[5]);
		graph.addEdge(vertexSet[2], vertexSet[6]);

		return graph;
	}
}