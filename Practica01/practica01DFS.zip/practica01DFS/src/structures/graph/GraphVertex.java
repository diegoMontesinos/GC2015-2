package geom.structures.graph;

import processing.core.PVector;

/**
 * Representa un vertice etiquetado de una gráfica.
 * Tiene un identificador (etiqueta) que lo identifica
 * en la gráfica. Además mantiene una posicion para su
 * manipulación.
 *
 */
public class GraphVertex {

	// El identificador del vertice
	private String id;

	// Su posicion
	private PVector position;

	/**
	 * Construye un vertice con el identificador y con la posicion dada
	 *
	 * @param id El identificador del vertice
	 * @param position La posicion del vertice
	 */
	public GraphVertex(String id, PVector position) {
		this.id = id;
		this.position = position;
	}

	/**
	 * Obtiene la posicion del vertice
	 *
	 * @return PVector La posicion del vertice
	 */
	public PVector getPosition() {
		return this.position;
	}

	/**
	 * Cambia la posicion del vertice
	 *
	 * @param position La nueva posicion del vertice
	 */
	public void setPosition(PVector position) {
		this.position = position;
	}

	/**
	 * Obtiene el identificador del vertice
	 *
	 * @return String El identificador
	 */
	public String getId() {
		return this.id;
	}

}