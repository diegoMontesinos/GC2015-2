package geom.structures.dcel2D.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertNull;

import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.junit.Test;

import processing.core.PApplet;
import geom.structures.dcel2D.*;

import java.util.List;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class DCELTest {

	@Test
	public void test1AdjacentHEsToVertex() {
		Dcel2D dcel = DCELUtils.readSvg("data/exampleA.svg", new PApplet());
		Vertex2D vertex = dcel.vertices.get("289,125");

		List<HalfEdge2D> halfEdges = dcel.adjacentHalfEdges(vertex);
		assertNotNull(halfEdges);

		assertEquals(4, halfEdges.size());

		boolean allIn = false;
		for (int i = 0; i < halfEdges.size(); i++) {
			HalfEdge2D he = halfEdges.get(i);
			String id = he.getId();
			boolean test = id.equals("289,125-390,140") || id.equals("289,125-332,356") || id.equals("289,125-255,202") || id.equals("289,125-217,63");

			allIn = allIn && test;
		}
		assertTrue(allIn);
	}

	@Test
	public void test2AdjacentFacesToFace() {
		Dcel2D dcel = DCELUtils.readSvg("data/exampleA.svg", new PApplet());
		Face2D face = dcel.faces.get("332,356 360,446 500,246 480,100 390,140 289,125");

		List<Face2D> faces = dcel.adjacentFaces(face);
		assertNotNull(faces);

		assertEquals(5, faces.size());

		boolean allIn = true;
		boolean outerIn = false;
		for (int i = 0; i < faces.size(); i++) {
			Face2D f = faces.get(i);

			if(f.isOuterFace()) {
				outerIn = true;
			} else {
				String id = f.getId();
				boolean test = id.equals("332,356 183,328 113,410 360,446") || id.equals("80,257 113,410 183,328 332,356 289,125 255,202") ||
							   id.equals("217,63 80,257 255,202 289,125") || id.equals("289,125 390,140 480,100 217,63") ||
							   id.equals("480,100 500,246 560,160");
				allIn = allIn && test;
			}
		}
		allIn = allIn && outerIn;
		assertTrue(allIn);
	}

	@Test
	public void test3AdjacentHEsToFace() {
		Dcel2D dcel = DCELUtils.readSvg("data/exampleB.svg", new PApplet());
		Face2D face = dcel.faces.get("160,100 200,500 450,100");

		List<HalfEdge2D> halfEdges = dcel.adjacentHalfEdges(face);
		assertNotNull(halfEdges);

		assertEquals(3, halfEdges.size());

		boolean allIn = true;
		for (int i = 0; i < halfEdges.size(); i++) {
			HalfEdge2D he = halfEdges.get(i);
			String id = he.getId();

			boolean test = id.equals("160,100-200,500") || id.equals("200,500-450,100") || id.equals("450,100-160,100");
			allIn = allIn && test;
		}
		assertTrue(allIn);

		///////////////////////////////////////////////

		face = dcel.getOuterFace();

		halfEdges = dcel.adjacentHalfEdges(face);
		assertNotNull(halfEdges);

		assertEquals(7, halfEdges.size());

		allIn = true;
		for (int i = 0; i < halfEdges.size(); i++) {
			HalfEdge2D he = halfEdges.get(i);
			String id = he.getId();

			boolean test = id.equals("300,10-450,100") || id.equals("450,100-500,500") || id.equals("500,500-200,500") ||
						   id.equals("200,500-4,300") || id.equals("4,300-10,150") || id.equals("10,150-160,100") || id.equals("160,100-300,10");
			allIn = allIn && test;
		}
		assertTrue(allIn);
	}

}