package geom.structures;

import java.util.List;
import java.lang.IllegalArgumentException;

/**
 * Representa un polígono simple en dos dimensiones, como una sucesión
 * de puntos (vectores de dos dimensiones).
 *
 */
public class Polygon2D {

	/**
	 * Construye un polígono sin puntos.
	 *
	 */
	public Polygon2D() {
	}

	/**
	 * Construye el polígono dada una lista de puntos.
	 *
	 * @param points Los puntos que representarán al polígono.
	 */
	public Polygon2D(List<Vector2D> points) {
	}

	/**
	 * Agrega un nuevo punto al final de la sucesión del polígono.
	 *
	 * @param point El nuevo punto en el polígono.
	 */
	public void add(Vector2D point) {
	}

	/**
	 * Devuelve una lista con los vértices del polígono en el orden
	 * por convención (contrario a las manecillas del reloj).
	 *
	 * @return List<Vector2D> La lista de vértices
	 */
	public List<Vector2D> getVertexes() {
		return null;
	}

	/**
	 * Devuelve una lista con los vértices del polígono en orden
	 * a favor de las manecillas del reloj (lo opuesto a la convencion).
	 * NOTA: el vertice inicial no cambia
	 *
	 * @return List<Vector2D> La lista de vértices
	 */
	public List<Vector2D> getClockwiseVertexes() {
		return null;
	}

	/**
	 * Calcula el centro de masa del polígono.
	 * NOTA: Se asume que el polígono es convexo.
	 *
	 * @return Vector2D El vector que representa el centro de masa del polígono.
	 */
	public Vector2D getCentroid() {
		return null;
	}

	/**
	 * Verifica si el polígono es convexo o no.
	 *
	 * @return boolean Si el polígono es convexo.
	 */
	public boolean isConvex() {
		return false;
	}

	/**
	 * Verifica si un punto está dentro o sobre el polígono.
	 * NOTA: Para esta práctica, este método supone que el polígono
	 * es convexo.
	 *
	 * @param point El punto a verificar.
	 * @return boolean Si el punto esta contenido o no.
	 */
	public boolean containsPoint(Vector2D point) {
		return false;
	}

	/**
	 * Limpia el polígono.
	 *
	 */
	public void clear() {
	}

	/**
	 * Regresa el número de vértices del polígono.
	 *
	 * @return int El número de vértices
	 */
	public int size() {
		return -1;
	}

	/**
	 * Regresa el vértice más a la izquierda del polígono
	 *
	 * @return Vector2D El vértice más a la izquierda.
	 */
	public Vector2D leftmostVerex() {
		return null;
	}

	/**
	 * Regresa el vértice más a la derecha del polígono
	 *
	 * @return Vector2D El vértice más a la derecha.
	 */
	public Vector2D rightmostVertex() {
		return null;
	}

	/**
	 * Regresa el vértice con más abajo del polígono
	 *
	 * @return Vector2D El vértice más abajo.
	 */
	public Vector2D lowestVertex() {
		return null;
	}

	/**
	 * Regresa el vértice con más arriba del polígono
	 *
	 * @return Vector2D El vértice más arriba.
	 */
	public Vector2D highestVertex() {
		return null;
	}

}
