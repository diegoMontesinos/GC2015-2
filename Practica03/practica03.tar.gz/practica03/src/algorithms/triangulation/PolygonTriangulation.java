package geom.algorithms.triangulation;

import geom.structures.dcel2D.*;

/**
 * Implementación del algoritmo para triangular un polígono simple.
 * Ocupa la división del polígono en piezas monótonas de la clase
 * MonotoneDivision.
 *
 * HINT: podrías ocupar un método extra cuya firma podría ser algo como:
 *  triangulateMonotone(monotone)
 *
 */
public class PolygonTriangulation {

	/**
	 * Divide en triangulos, es decir, triangula un polígono simple.
	 * Este polígono está descrito en la DCEL de entrada.
	 *
	 * La triangulación modifica la DCEL de entrada, por lo que todas
	 * las modificaciones se hacen sobre la estructura.
	 *
	 * Este metodo debe ocupar la division de piezas monótonas. 
	 *
	 * @param dcel El polígono simple descrito en la DCEL
	 */
	public static void triangulatePolygon(Dcel2D dcel) {
	}
	
}
