package geom.algorithms.convexHull;

import geom.structures.Polygon2D;
import geom.structures.Vector2D;

/**
 * Implementación del algoritmo incremental
 * para construir el cierre convexo de un 
 * conjunto de puntos.
 *
 */
public class IncrementalCH {

	/**
	 * Crea una instancia de este algoritmo.
	 *
	 */
	public IncrementalCH() {
	}

	/**
	 * Calcula el cierre convexo dado un arreglo de puntos.
	 *
	 * @param points El arreglo de puntos para obtener el cierre
	 * @return Polygon2D El cierre convexo calculado.
	 */
	public Polygon2D calculateConvexHull(Vector2D[] points) {
		return null;
	}

	/**
	 * Calcula el cierre convexo de la unión de un cierre convexo
	 * con un punto, es decir, agrega el punto al cierre convexo
	 * para obtener una solución de un conjunto más grande de puntos.
	 *
	 * @param convexHull El cierre convexo al que se agregara el punto
	 * @param point El punto a agregar
	 * @return Polygon2D El cierre convexo resultante
	 */
	public Polygon2D append(Polygon2D convexHull, Vector2D point) {
		return null;
	}

	/**
	 * Calcula los puntos en un cierre convexo que forman, junto con un punto dado
	 * las tangentes necesarias para unir dicho punto con el cierre convexo.
	 *
	 * @param convexHull El cierre convexo del que se obtendran las tangentes
	 * @param point El punto a tratar
	 * @return Vector2D[] Un arreglo con los dos puntos que hacen las tangentes
	 */
	public Vector2D[] getTangentsPoints(Polygon2D convexHull, Vector2D point) {
		return null;
	}
}
