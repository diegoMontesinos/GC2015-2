package geom.structures;

import processing.core.PVector;

/**
 * Representa un vértice en dos dimensiones, se basa
 * en la implementación PVector del core de Processing.
 *
 */
public class Vector2D {

	// El vector perse
	public PVector vector;

	/**
	 * Construye el vector en el origen.
	 *
	 */
	public Vector2D() {
		this.vector = new PVector(0, 0);
	}

	/**
	 * Construye el vector dadas sus coordenadas
	 *
	 * @param x La coordenada x del vector.
	 * @param y La coordenada y del vector.
	 */
	public Vector2D(float x, float y) {
		this.vector = new PVector(x, y);
	}

	/**
	 * Construye el vector dado el vector de Processing.
	 *
	 * @param vector El vector perse.
	 */
	public Vector2D(PVector vector) {
		this.vector = vector;
	}

	public boolean equals(Vector2D vec2D) {
		return this.vector.equals(vec2D.vector);
	}

}
