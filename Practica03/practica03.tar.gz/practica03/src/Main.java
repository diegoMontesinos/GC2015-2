package practica03;

//import geom.structures.dcel2D.*;
//import processing.core.PApplet;

import geom.structures.dcel2D.*;
import geom.visualization.*;
import java.util.LinkedList;

import processing.core.PApplet;
import javax.swing.JFrame;
import java.awt.BorderLayout;
import java.awt.Dimension;

public class Main {

	public static void main(String[] args) {
		System.out.println("hola mundo");

		// Creamos un frame y lo configuramos: titulo, layout y medidas
		JFrame sketchFrame = new JFrame();
		sketchFrame.setLayout(new BorderLayout());
		sketchFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		sketchFrame.setPreferredSize(new Dimension(700, 700));

		// Creamos el objeto de nuestro sketch dependiendo de los argumentos
		DCELSketch sketch = new DCELSketch();
		sketchFrame.setTitle("123");

		// Agregamos el sketch al frame
		sketchFrame.getContentPane().add(sketch, BorderLayout.CENTER);
		sketchFrame.pack();

		// Hacemos visible el frame e iniciamos el sketch
		sketchFrame.setVisible(true);
		sketch.init();
	}

}